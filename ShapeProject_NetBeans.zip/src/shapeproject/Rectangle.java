package shapeproject;
public class Rectangle extends Shape{
    private double width,height;
    public Rectangle(double width,double height) throws InvalidShapeException{
        if(width<=0||height<=0) throw new InvalidShapeException("Width and Height must be positive");
        this.width=width; this.height=height;
    }
    public double getArea(){ return width*height; }
    public double getPerimeter(){ return 2*(width+height); }
    public void resize(double factor){
        if(factor<=0) throw new IllegalArgumentException("Factor must be positive");
        width*=factor; height*=factor;
    }
    public String toString(){ return "Rectangle Width="+width+", Height="+height; }
}