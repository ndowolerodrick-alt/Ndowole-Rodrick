package shapeproject;
public class ShapeDemo {
    public static void main(String[] args){
        try{
            Circle c=new Circle(7);
            Rectangle r=new Rectangle(5,4);
            Triangle t=new Triangle(3,4,5);
            Shape[] shapes={c,r,t};
            printAreas(shapes);
            System.out.println("\nLargest Shape: "+largest(shapes));
            Triangle bad=new Triangle(1,2,10);
        }catch(InvalidShapeException e){
            System.out.println("Exception caught: "+e.getMessage());
        }
    }
    public static void printAreas(Shape[] shapes){
        for(Shape s:shapes){
            System.out.println(s+" Area = "+s.getArea());
        }
    }
    public static Shape largest(Shape[] shapes){
        Shape largest=shapes[0];
        for(Shape s:shapes){
            if(s.getArea()>largest.getArea()) largest=s;
        }
        return largest;
    }
}